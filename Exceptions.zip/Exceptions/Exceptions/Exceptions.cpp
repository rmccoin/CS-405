// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
// EDIT //
#include <stdexcept>    // added to define standard exception classes from the C++ Standard Library
#include <string>       // added to incorporate contents of the string header file into the source code 

// EDIT //
// Custom exception class from std::exception
class customException : public std::exception {     // define class name as customException and inherit std::exception, this will allow us to catch the custom exception when using catch later in the code. 
private:
    std::string message;    // message will store the custom message associated with the exception 
public:
    explicit customException(const std::string& msg) : message(msg) {}      // constructor for customeException that takes std::string called msg and assigns it to the internal message using : message(msg)
    const char* what() const noexcept override {        // returns a string with a description of the error. noexcept guarantees no exception will be thrown by this function.  
        return message.c_str();     // message.c_str() converts std::string to a constant character with a pointer (const char*) 
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // EDIT //
    throw std::runtime_error("Standard exception thrown in Even More Custom Application Logic");    // std::runtime_error is used when an error occurs.  This error can only be detected at runtime.  

    return true;
}


void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    // EDIT //
    // Added a try block to prevent the application from crashing or terminating unexpectedly.  This try block will catch the exception and safely handles the code.  
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }

    // EDIT //
    // Catch block catches exceptions that inherits from std::exception 
    catch (const std::exception& ex) {
        std::cerr << "Caught exception in do_custom_application_logic: " << ex.what() << std::endl;     // prints the error message passed when the exception was thrown using ex.what() and the output goes to std::cerr (standard error stream) used for outputing error messages. 
    }
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    // EDIT //
    // try block to combine both the throw and catch into one function to prevent from leaving the function before std::out can run 
    try {
        throw customException("Custom exception thrown in custom application logic");   // Throws an instance from the customException  we defined earlier and prints an error message. 
    }
    catch (const customException& ex) {
        std::cerr << "Caught custom exception: " << ex.what() << std::endl;     // by adding the throw and catch in the same function, we catch the custom exception early and prevent from exiting the function before the next statement "Leaving Custom Application Logic." prints. 
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    // EDIT // 
    if (den == 0.0f) {  // checks to see if the denominator is zero using den == 0.0f
        throw std::runtime_error("Error, dividing by zero is not allowed.");        // if the denominator is zero, than an error message will appear explaining this is not allowed. throw interrupts the function and goes to the next catch block. 
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    // EDIT //
    // used a try block to contain the call to divide() in case it throws an error (std::runtime_error) if the denominator is equal to zero. 
    try {
        auto result = divide(numerator, denominator);      //
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;  // if no exception occurs then the results will print
    }
    // handles the std::runtime_error if it matches the exception thrown (denominator equals zero) inside the divide 
    catch (const std::runtime_error& ex) {
        std::cerr << "Caught runtime error in do_division: " << ex.what() << std::endl;     // prints error message if it matches the exception thrown 
    }

}

int main()
{
    // 
    try{
        std::cout << "Exceptions Tests!" << std::endl;

        // TODO: Create exception handlers that catch (in this order):
        //  your custom exception
        //  std::exception
        //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.
        do_division();
        do_custom_application_logic();
    }

    // EDIT //
    catch (const customException& ex) {      // catches the customException inherited from std::exception.  Must come before catch (std::exception&) or else it will never be reached. 
        std::cerr << "Caught customException in main: " << ex.what() << std::endl;       // displays the what() message for debugging 
    }
    catch (const std::exception& ex) {      // catches the std::exception.  This catches common exceptions, that are not custom.   
        std::cerr << "Caught std::exception in main: " << ex.what() << std::endl;       // displays the what() message for debugging 
    }
    catch (...) {       // catch (...) catches any exceptions not caught in the blocks above. 
        std::cerr << "Caught unknown exception in main." << std::endl;      // Displays message if it catches an unexpected exception 
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
