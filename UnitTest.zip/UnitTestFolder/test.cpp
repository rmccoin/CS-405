// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

//  Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    // EDIT //
    ASSERT_TRUE(collection->empty());       // ASSERT_TRUE makes the test stop immediately if the collection is not empty 

    add_entries(1); // adds 1 random integer to collection

    // is the collection still empty?
    // if not empty, what must the size be?
    // EDIT //
    ASSERT_EQ(collection->size(), 1);       // verfies the collection contains exactly 1 element after we added 1 to the collection. If it is not 1 then the test fails. 
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);
    // Edit //
    ASSERT_EQ(collection->size(), 5);       // this line checks if the collection contains exactly 5 elements. If it does not it fails.  Assert_EQ stops the test immediately if condition not met. 
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
// Edit //
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualSize) {     // Defines the Google Test using CollectionTest. Name of test is defined as MaxSizeGreaterThanOrEqualSize
    std::vector<int> test_sizes = { 0, 1, 5, 10 };      // initializes a vector of the values 0, 1, 5, and 10. 

    for (int size : test_sizes) {       // loops through each test size, 0, 1, 5, and 10. 
        collection->clear();    // Reset collection using clear()
        if (size > 0) add_entries(size);        // if statement that says if the size is greater than 0 then it will add that many entries to the collection.  
        ASSERT_GE(collection->max_size(), collection->size());      // Test that verifies that the max_size the vector can hold is greater than or equal to the number of items it currently has in it.  
    }
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
// Edit //
TEST_F(CollectionTest, CapacityGreaterThanOrEqualSize) {        // Defines the Google Test using CollectionTest. Name of the test defined as CapacityGreaterThanOrEqualSize.
    std::vector<int> test_sizes = { 0, 1, 5, 10 };      // initializes a vector of the values 0, 1, 5, and 10.

    for (int size : test_sizes) {       // loops through each test size, 0, 1, 5, and 10.
        collection->clear();    // Reset collection using clear()
        if (size > 0) add_entries(size);        // if statement that says if the size is greater than 0 then it will add that many entries to the collection.
        ASSERT_GE(collection->capacity(), collection->size())       // Test that verifies that the capacity the vector can hold is greater than or equal to the number of items it currently has in it. 
            << "Failed for size: " << collection->size();       // Identifies which case failed if the test were to break. 
    }
}

// TODO: Create a test to verify resizing increases the collection
// EDIT //
TEST_F(CollectionTest, ResizeIncreasesSize) {       // Defines the Google Test using CollectionTest. Name of the test defined as ResizeIncreasesSize.
    collection->resize(5);      // resizes the vector to be able to contain 5 elements 
    ASSERT_EQ(collection->size(), 5);       // check the vector to make sure it now can hold exactly 5 elements. If it does not then the test fails. Verifies resize increased the number of elements. 
}

// TODO: Create a test to verify resizing decreases the collection
// EDIT //
TEST_F(CollectionTest, ResizeDecreasesSize) {       // Defines the Google Test using CollectionTest. Name of the test defined as ResizeDecreasesSize
    add_entries(10);        // Adds 10 random integers to the collection 
    collection->resize(5);      // resizes the vector to be able to contain 5 elements 
    ASSERT_EQ(collection->size(), 5);       // check the vector to make sure it now can hold exactly 5 elements. If it does not then the test fails. Verifies resize decreased the number of elements by adding 10 and changing to 5. 
}

// TODO: Create a test to verify resizing decreases the collection to zero
// EDIT //
TEST_F(CollectionTest, ResizeToZeroClearsCollection) {      // Defines the Google Test using CollectionTest. Name of the test defined as ResizeToZeroClearsCollection
    add_entries(5);     // Adds 5 random integers to the collection
    collection->resize(0);       // resizes the vector to be able to contain no elements
    ASSERT_TRUE(collection->empty());       // Checks to make sure the vector is empty after resizing to 0.  If it is empty the test passes, if not the test fails. 
}

// TODO: Create a test to verify clear erases the collection
// EDIT //
TEST_F(CollectionTest, ClearErasesCollection) {     // Defines the Google Test using CollectionTest. Name of the test defined as ClearErasesCollection
    add_entries(3);      // Adds 3 random integers to the collection
    collection->clear();        // Reset collection using clear()
    ASSERT_EQ(collection->size(), 0);       // Checks if the vector size is 0 after clearing
    ASSERT_TRUE(collection->empty());       // Confirms the vector is empty after clearing. If empty then the test passes, if not then the test fails. 
}

// TODO: Create a test to verify erase(begin,end) erases the collection
// EDIT //
TEST_F(CollectionTest, EraseBeginToEndClearsCollection) {       // Defines the Google Test using CollectionTest. Name of the test defined as EraseBeginToEndClearsCollection
    add_entries(5);      // Adds 5 random integers to the collection
    collection->erase(collection->begin(), collection->end());      // Erases all elements between begin() to end(), which is from the first element to just past the last element. 
    ASSERT_TRUE(collection->empty());       // Confirms the vector is empty after erasing. 
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
// EDIT //
TEST_F(CollectionTest, OutOfRangeThrowsException) {     // Defines the Google Test using CollectionTest. Name of the test defined as  OutOfRangeThrowsException
    add_entries(3);      // Adds 3 random integers to the collection
    EXPECT_THROW(collection->at(5), std::out_of_range);     // Tries to access element at index 5 with (collection->at(5)) and throws exception (std::out_of_range).  This is because the index is past the current size of the vector. 
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// EDIT //
// Positive Test //
TEST_F(CollectionTest, InsertedValuesMaintainOrder) {       // Defines the Google Test using CollectionTest. Name of the test defined as InsertedValuesMaintainOrder
    // these lines insert the integers 10, 20, and 30 into the collection using push_back. 
    collection->push_back(10);
    collection->push_back(20);
    collection->push_back(30);

    ASSERT_EQ(collection->size(), 3);       // Checks the size of the collection is exactly 3.  This confirms that all three of the values 10, 20, and 30 were successfuly inserted. 
    EXPECT_EQ(collection->at(0), 10);       // Uses EXPECT_EQ to verify that the values in the vector remained in the same order they were put in. . at(0) will throw an exception if an invalid index is used. 
    EXPECT_EQ(collection->at(1), 20);       // Uses EXPECT_EQ to verify that the values in the vector remained in the same order they were put in. . at(1) will throw an exception if an invalid index is used.
    EXPECT_EQ(collection->at(2), 30);       // Uses EXPECT_EQ to verify that the values in the vector remained in the same order they were put in. . at(2) will throw an exception if an invalid index is used.
}

// Negative Test //
TEST_F(CollectionTest, AccessingInvalidIndexThrowsException) {      // Defines the Google Test using CollectionTest. Name of the test defined as AccessingInvalidIndexThrowsException
    add_entries(2);     // Adds 2 random integers to the collection
    EXPECT_THROW(collection->at(5), std::out_of_range);     // Attempt to access index 5, which is invalid because we set the bounds to 2. EXPECT_THROW verifies the correct exception is thrown. 
}